function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}

var form = document.getElementById("form");
form.addEventListener("submit", function (e) {
  e.preventDefault();

  const formData = new FormData(form);
  const data = Object.fromEntries(formData);

  //post
  

  fetch("http://localhost:2002/customorsdata", {
    method: "post",
    headers: { "Content-Type": "application/json; charset=UTF-8" },
    body: JSON.stringify(data),
  })
    .then((res) => res.json())
    .then((data) => console.log(data))
    .catch((error) => console.log(error));
});

// get

const promise = fetch("http://localhost:2002/mongotonodefulldata")
  .then(function (res) {
    if (res.status === 200) return res.json();
    else throw new Error("Something Failed..");
  })
  .then(function (data) {
    // console.log(data);
    // console.log(data[1]);
    let tableData = "";

    data.map((values) => {
      tableData += `<tr>
        <td>${values.name}</td>
        <td>${values.email}</td>
        <td>${values.address}</td>
        <td>${values.phoneNo}</td>
        <td>
        
        <button type="button" class="btn btn-primary edit" >
        Edit
        </button>

    
       <button class="btn btn-danger delete">Delete</button>
              
      </td>
      </tr>`;
    });
    document.getElementById("table_body").innerHTML = tableData;
  })
  .catch(function (err) {
    console.log(err.message);
  });

// // delete

fetch("http://localhost:2022/del", {
  method: "delete",

  headers: {
    "Content-Type": "application/json; charset=UTF-8",
  },
})
  .then((res) => {
    if (res.ok) {
      console.log("HTTP request successful");
    } else {
      console.log("HTTP request unsuccessful");
    }
    return res;
  })

  .then(function (response) {
    return response.json();
  })
  .then(function (data) {
    console.log(data);
  })
  .catch(function (error) {
    console.log(error);
  });
